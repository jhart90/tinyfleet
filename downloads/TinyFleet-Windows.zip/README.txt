TinyFleet 4.2

WINDOWS
  Unzip everything, then double-click TinyFleet.exe.
  If Windows says "Windows protected your PC", click "More info" then "Run anyway"
  (the game isn't code-signed).

MAC
  Unzip, drag TinyFleet.app into Applications if you like, then double-click it.
  The first time, macOS may say it can't check the app for malware (it isn't signed by Apple).
  Click Done, open System Settings > Privacy & Security, scroll down and click "Open Anyway"
  next to TinyFleet, then open it again. (Older macOS: right-click the app > Open.)

Both open the game in its own window in Chrome or Edge if you have one, otherwise in your
default browser. Your saves stay on this computer and carry over to new versions.
